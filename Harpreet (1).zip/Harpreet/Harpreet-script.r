#---------------------------------------------
# Identifying human Tfs in list of genes
#---------------------------------------------


# Load data
table <- data.table::fread("D:/DKFZ/Harpreet/table.tsv")
TF_list <- read.csv("D:/DKFZ/Harpreet/human_TFs.txt", col.names = "TF_hgnc_idents",stringsAsFactors = FALSE)


# Take the "table", filter those rows in column "Correlated Gene" 
#that are the same in "table" and in "TF_list". Then, take that, further filter for those which q-value is
#lower than 0.01. Then take that and filter for those that have SC greater than 0.2

#install.packages ("diplyr") # you will need to install this package first
library("dplyr")

TF_list_lc <- TF_list %>%
  mutate (TF_hgnc_idents = tolower(TF_hgnc_idents))

TF_data_list <- table %>%
  mutate(`Correlated Gene` = tolower(`Correlated Gene`)) %>%
  filter(`Correlated Gene` %in% TF_list_lc$TF_hgnc_idents) %>%
  filter(`q-Value` < 0.01) %>%
  filter(`Spearman's Correlation` > 0.2 |`Spearman's Correlation` < -0.2 )


hist(TF_data_list$Spearman.s.Correlation,
     breaks = 100,
     main = "Histogram of correlation values",
     xlab = "Spear. correlation")


library(ggplot2)


ggplot(data = TF_data_list)+
  geom_histogram(aes(x = Spearman.s.Correlation),inherit.aes = FALSE)


# Some useful links

# This is were the TF names come from:

# Website:
# http://humantfs.ccbr.utoronto.ca/

# Publication (also stated on the website):
# https://www.sciencedirect.com/science/article/pii/S0092867418301065




# Here you would get Transcription factors motives:
# http://jaspar.genereg.net/search?q=Homo%20sapiens&collection=CORE&tax_group=vertebrates



# example plots
#------------------------

# histogram (of all TFs)
hist(TF_data_list$Spearman.s.Correlation,
     breaks = 100,
     main = "Histogram of correlation values",
     xlab = "Spear. correlation")




