#------------------------------------------------------------------------
# Check if TFs are differentially expressed in PRPFA/B specific samples
#------------------------------------------------------------------------


# Load data

diff_expressed_gened <- data.table::fread("C:/Users/clanc/Desktop/Harpreet/differentially_expressed_genes.tsv")

homA_activators = data.table::fread('C:/Users/clanc/Desktop/Harpreet/activators_PRPF40A.txt')
homA_repressors = data.table::fread('C:/Users/clanc/Desktop/Harpreet/repressors_PRPF40A.txt')

homB_activators = data.table::fread('C:/Users/clanc/Desktop/Harpreet/activators_PRPF40B.txt')
homB_repressors = data.table::fread('C:/Users/clanc/Desktop/Harpreet/repressors_PRPF40B.txt')


# filter table by homolog A
TF_data_list_hom_A <- diff_expressed_gened[which(
  diff_expressed_gened$`Higher expression in` == 'PRPF40A')]
# filter for sgnificance
TF_data_list_hom_A_sig <- TF_data_list_hom_A[which(TF_data_list_hom_A$`q-Value`<= 0.05),]

# reduce to differentially expressed TFs
homA_activators_diff_expressed = homA_activators[which(homA_activators$Cor_Gene %in%
                                                         TF_data_list_hom_A_sig$Gene),]

homA_repressors_diff_expressed = homA_repressors[which(homA_repressors$Cor_Gene %in%
                                                         TF_data_list_hom_A_sig$Gene),]

TF_hom_A_expression = TF_data_list_hom_A_sig[which(TF_data_list_hom_A_sig$Gene %in%
                                                     homA_activators_diff_expressed$Cor_Gene)]


# filter table by homolog B
TF_data_list_hom_B <- diff_expressed_gened[which(
  diff_expressed_gened$`Higher expression in` == 'PRPF40B')]
# filter for sgnificance
TF_data_list_hom_B_sig <- TF_data_list_hom_B[which(TF_data_list_hom_B$`q-Value`<= 0.05),]

# reduce to differentially expressed TFs
homB_activators_diff_expressed = homB_activators[which(homB_activators$Cor_Gene %in%
                                                         TF_data_list_hom_B_sig$Gene),]

homB_repressors_diff_expressed = homB_repressors[which(homB_repressors$Cor_Gene %in%
                                                         TF_data_list_hom_B_sig$Gene),]

TF_hom_B_expression = TF_data_list_hom_B_sig[which(TF_data_list_hom_B_sig$Gene %in%
                                                     homB_activators_diff_expressed$Cor_Gene)]









