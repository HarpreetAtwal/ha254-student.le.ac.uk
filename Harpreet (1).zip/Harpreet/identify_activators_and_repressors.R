#---------------------------------------------
# Identifying human Tfs in list of genes
#---------------------------------------------


# Load data
#library("tidyverse")
# tableT <- read_csv(file = 'D:/DKFZ/Harpreet/table.tsv', col_names = TRUE)
# #table <- data.table::fread("C://Users//Ivana//Documents//DKFZ//table.tsv") 
# TF_list <- read_csv("D:/DKFZ/Harpreet/human_TFs.txt", col_names = "TF_hgnc_idents")

table <- data.table::fread("C:/Users/clanc/Desktop/Harpreet/co_expression_PRPFA.tsv")
TF_list <- read.csv("C:/Users/clanc/Desktop/Harpreet/human_TFs.txt", col.names = "TF_hgnc_idents",stringsAsFactors = FALSE)

colnames(table) <- c("Cor_Gene", "Cytoband", "Spear_Cor", "p_Value", "q_Value")

# Select rows in data table that are TFs
TF_data_list <- table[which(table$Cor_Gene %in% TF_list$TF_hgnc_idents),]


# Filter TFs for significance threshold (q_value <0.01),
# (basically means you expect less than 1% folse positives in your hits, but probably still a lot of unrelavant ones)
TF_data_list_qVal_0.01 <- TF_data_list[which(TF_data_list$q_Value < 0.01),]


# Filter further for correlation cut-off 0.2

# ( hopefully they are biologically more relavant activators (positive correlation) or repressors (negative correlation))
# Activators:
TF_data_activators <- TF_data_list_qVal_0.01[which(TF_data_list_qVal_0.01$Spear_Cor > 0.2),]
write.table(TF_data_activators, 'C:/Users/clanc/Desktop/Harpreet/activators_PRPF40A.txt',
            sep = '\t', quote = F, row.names = F)

# Repressors:
TF_data_repressors <- TF_data_list_qVal_0.01[which(TF_data_list_qVal_0.01$Spear_Cor < -0.2),]
write.table(TF_data_repressors, 'C:/Users/clanc/Desktop/Harpreet/repressors_PRPF40A.txt',
            sep = '\t', quote = F, row.names = F)


# for hom B
#------------------
table <- data.table::fread("C:/Users/clanc/Desktop/Harpreet/co_expression_PRPFB.tsv")
TF_list <- read.csv("C:/Users/clanc/Desktop/Harpreet/human_TFs.txt", col.names = "TF_hgnc_idents",stringsAsFactors = FALSE)

colnames(table) <- c("Cor_Gene", "Cytoband", "Spear_Cor", "p_Value", "q_Value")

# Select rows in data table that are TFs
TF_data_list <- table[which(table$Cor_Gene %in% TF_list$TF_hgnc_idents),]


# Filter TFs for significance threshold (q_value <0.01),
# (basically means you expect less than 1% folse positives in your hits, but probably still a lot of unrelavant ones)
TF_data_list_qVal_0.01 <- TF_data_list[which(TF_data_list$q_Value < 0.05),]


# Filter further for correlation cut-off 0.2

# ( hopefully they are biologically more relavant activators (positive correlation) or repressors (negative correlation))
# Activators:
TF_data_activators <- TF_data_list_qVal_0.01[which(TF_data_list_qVal_0.01$Spear_Cor > 0.2),]
write.table(TF_data_activators, 'C:/Users/clanc/Desktop/Harpreet/activators_PRPF40B.txt',
            sep = '\t', quote = F, row.names = F)

# Repressors:
TF_data_repressors <- TF_data_list_qVal_0.01[which(TF_data_list_qVal_0.01$Spear_Cor < -0.2),]
write.table(TF_data_repressors, 'C:/Users/clanc/Desktop/Harpreet/repressors_PRPF40B.txt',
            sep = '\t', quote = F, row.names = F)



# Some useful links
#-----------------------


# This is were the TF names come from:

# Website:
# http://humantfs.ccbr.utoronto.ca/

# Publication (also stated on the website):
# https://www.sciencedirect.com/science/article/pii/S0092867418301065




# Here you would get Transcription factors motives:
# http://jaspar.genereg.net/search?q=Homo%20sapiens&collection=CORE&tax_group=vertebrates

# and a tutorial:
# https://bioconductor.org/packages/devel/workflows/vignettes/generegulation/inst/doc/generegulation.html


# example plots
#------------------------

# histogram (of all TFs)
hist(TF_data_list$Spearman.s.Correlation,
     breaks = 100,
     main = "Histogram of correlation values",
     xlab = "Spear. correlation")




